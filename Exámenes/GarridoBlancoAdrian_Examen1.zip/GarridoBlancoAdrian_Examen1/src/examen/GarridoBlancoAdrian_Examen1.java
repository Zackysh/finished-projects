package examen;

import java.util.ArrayList;
import java.util.Arrays;

import lib.Compute;

public class GarridoBlancoAdrian_Examen1 {
	
	/**
	 * M�todo que imprime por consola una matriz.
	 * 
	 * @param m Matriz a imprimir.
	 */
	public static void printMatrix(int[][]m) {
		if(m != null)
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m[0].length; j++) {
				System.out.print(" " + m[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	/**
	 * M�todo que imprime por consola un array,
	 * 
	 * @param array Array a imprimir.
	 */
	public static void printArray(int[] array) {
		if(array != null) {
			System.out.print("{");
			for (int i = 0; i < array.length; i++) {
				System.out.print(array[i]);
				if(i != array.length - 1) System.out.print(", ");
			}
			System.out.print("}\n");
		}		
	}
	
	public static void printArray(String[] array) {
		if(array != null) {
			System.out.print("{");
			for (int i = 0; i < array.length; i++) {
				System.out.print(array[i]);
				if(i != array.length - 1) System.out.print(", ");
			}
			System.out.print("}\n");
		}		
	}

	/**
	 * M�todo que dado un String[] lista de palabras y un String palabra, comprueba
	 * si palabra aparece en la lista.
	 * 
	 * @param lista   String[] que contiene la lista de palabras
	 * @param palabra Palabra que se desea buscar dentro del array
	 * @return
	 */
	public static boolean buscarPalabraEnArray(String[] lista, String palabra) {

		for (int i = 0; i < lista.length; i++) {
			if (lista[i] == palabra)
				return true;
		}

		return false;
	}

	/**
	 * M�todo que rota una matriz 90� en sentido horario. No modifica la original,
	 * devuelve una nueva.
	 * 
	 * @param matriz Matriz que se desea rotar.
	 * @return rotatedMatrix Matriz original rotada.
	 */
	public static int[][] voltearMatrizSentidoHorario(int[][] matriz) {

		// Ahora el n� de filas pasa a ser el n� de columnas
		int row = matriz[0].length;
		int col = matriz.length;

		int[][] rotatedMatrix = new int[row][col];

		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[0].length; j++) {
				rotatedMatrix[j][(col - 1) - i] = matriz[i][j];
			}
		}

		return rotatedMatrix;
	}

	/**
	 * Para que funcione solo con matrices cuadradas descomentar el condicional if.
	 * 
	 * Dada una matriz cualquiera, esta funci�n capturar� la capa exterior de la
	 * matriz y crear� un array con los n�meros empezando por el extremo izquierdo
	 * superior y avanzando en sentido antihorario hasta completar el array de la
	 * capa exterior. Esta funci�n deber� funcionar �nicamente para matrices
	 * cuadradas, en caso contrario mostrar� error y devolver� null.
	 * 
	 * 
	 * @param matriz Matriz de la que se obtendr� la capa exterior.
	 * @returns null Si la matriz no es cuadrada.
	 * @returns capaExterior Si la matriz es cuadrada, contendr� la capa exterior en un string.
	 */
	public static int[] capaExteriorMatriz(int[][] matriz) {

//		if(matriz.length == matriz[0].length) {
			
			// Capa deseada		
			int[] capaExterior = new int[matriz.length * 2 + (matriz[0].length * 2 - 4)]; // Longitud de la "capa exterior" de cualquier matriz.
			
			// Componentes que rellenar�n el array capaExterior
			// Laterales (columnas)
			int[] lateralDerechoInvertido = Compute.getColumna(matriz, matriz[0].length - 1);
			lateralDerechoInvertido = Compute.invertir(lateralDerechoInvertido);
			int[] lateralIzquierdo = Compute.getColumna(matriz, 0);
			// Filas superior e inferior (filas sin extremos)
			int[] filaSuperior = Compute.getFila(matriz, 0);		
			int[] filaInferior = Compute.getFila(matriz, matriz.length - 1);
			
			filaSuperior = Arrays.copyOfRange(filaSuperior, 1, filaSuperior.length - 1);
			filaInferior = Arrays.copyOfRange(filaInferior, 1, filaInferior.length -1);
			
			int cont = 0;
			for (int i = 0; i < lateralIzquierdo.length; i++) {
				capaExterior[cont++] = lateralIzquierdo[i];
			}
			
			for (int i = 0; i < filaInferior.length; i++) {
				capaExterior[cont++] = filaInferior[i];
			}
			
			for (int i = 0; i < lateralDerechoInvertido.length; i++) {
				
				capaExterior[cont++] = lateralDerechoInvertido[i];
			}
			
			for (int i = 0; i < filaSuperior.length; i++) {
				capaExterior[cont++] = filaSuperior[i];
			}

			return capaExterior;
	//	}
//		System.out.println("La matriz debe ser cuadrada.");
//		return null;
	}
	
	public static void main(String[] args) {
		
		System.out.println(
				  "==================\n"
				+ "|  TEST METHOD   |\n"
				+ "==================\n");
		
		
		// Primera funci�n
		System.out.println("\n==========================================\n" + "Testing: \"public static boolean buscarPalabraEnArray(String[] lista, String palabra)\":\n");
		String[] lista = {"Arroz", "Curry", "Repollo", "Almendra", "Pollo", "Pizza"};
		
		System.out.print("Lista de palabras: ");
		printArray(lista);
		
		String palabra1 = "Pollo", palabra2 = "Cebolla";		
		
		boolean aparece1 = GarridoBlancoAdrian_Examen1.buscarPalabraEnArray(lista, palabra1);
		
		if(aparece1) System.out.println("La palabra " + "\"" + palabra1 + "\"" + " aparece dentro de la lista.");
		else System.out.println("La palabra " + "\"" + palabra1 + "\"" + " no aparece dentro de la lista.");
		
		boolean aparece2 = GarridoBlancoAdrian_Examen1.buscarPalabraEnArray(lista, palabra2);
		
		if(aparece2) System.out.println("La palabra " + "\"" + palabra2 + "\"" + " aparece dentro de la lista.");
		else System.out.println("La palabra " + "\"" + palabra2 + "\"" + " no aparece dentro de la lista.");
		
		// Segunda funci�n
		System.out.println("\n==========================================\n" + "Testing: \"public static int[][] voltearMatrizSentidoHorario(int[][] matriz)\":\n");
		int[][] matrizV = {{1, 2, 3},{4,5,6},{7,8,9}, {10,11,12}};
		
		System.out.println("Matriz cuadrada original:");
		printMatrix(matrizV);
		
		matrizV = voltearMatrizSentidoHorario(matrizV);
		System.out.println("Matriz rotada en sentido horario:");
		printMatrix(matrizV);		
		
		// Tercera funci�n
		System.out.println("\n==========================================\n" + "Testing: \"public static int[] capaExteriorMatriz(int[][] matriz)\":\n");
		int[][] matriz = {{1, 2, 3},{4, 5, 6},{7, 8, 9}};
		System.out.println("Matriz a tratar:");
		printMatrix(matriz);
		int[] capaExterior = GarridoBlancoAdrian_Examen1.capaExteriorMatriz(matriz);		

		if(capaExterior != null)
		System.out.print("Capa exterior de la matriz:");
		printArray(capaExterior);

	}

}
