package examen;
import lib.Compute;

public class Prueba {
	
	public static void printMatrix(int[][]m) {
		
		for (int i = 0; i < m.length; i++) {
			for (int j = 0; j < m[0].length; j++) {
				System.out.print(" " + m[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	public static void printArray(int[] array) {
		System.out.print("{");
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i]);
			if(i != array.length - 1) System.out.print(", ");
		}
		System.out.print("}\n");
	}
	
	public static void main(String[] args) {
		
		System.out.println(
				  "==================\n"
				+ "|  TEST METHOD   |\n"
				+ "==================\n");
		
		
		// Primera funci�n
		System.out.println("Testing: \"public static boolean buscarPalabraEnArray(String[] lista, String palabra)\":\n");
		String[] lista = {"Arroz", "Curry", "Repollo", "Almendra", "Pollo", "Pizza"};
		String palabra = "Pollo";
		
		boolean aparece = GarridoBlancoAdrian_Examen1.buscarPalabraEnArray(lista, palabra);
		
		if(aparece) System.out.println("La palabra aparece dentro de la lista.");
		else System.out.println("La palabra " + palabra + " no aparece dentro de la lista.");
		
		// Segunda funci�n
		System.out.println("Testing: \"public static int[] capaExteriorMatriz(int[][] matriz)\":\n");
		int[][] matriz = {{1, 2, 3},{4, 5, 6},{7, 8, 9}};
		int[] capaExterior = GarridoBlancoAdrian_Examen1.capaExteriorMatriz(matriz);
		
		System.out.println("Matriz a tratar:");
		printMatrix(matriz);
		System.out.print("Capa exterior de la matriz:");
		printArray(capaExterior);

	}
	
	
}
