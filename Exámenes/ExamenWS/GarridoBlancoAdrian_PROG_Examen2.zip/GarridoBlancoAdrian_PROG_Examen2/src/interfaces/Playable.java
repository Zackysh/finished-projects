package interfaces;

public interface Playable {
	public abstract String tocarInstrumento();
}
